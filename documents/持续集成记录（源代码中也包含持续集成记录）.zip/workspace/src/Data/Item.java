package Data;
import java.io.Serializable;

public class Item implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int ID;
	private String name;
	private double price;
	private int number;
	private double specialPrice;
	private double totalPrice;
	public Item(){
		
	}
	
	public Item(int ID,String name,double price,int number,double specialPrice,double totalPrice){
		this.set(ID, name, price, number, specialPrice, totalPrice);
	}
	public void set(int ID,String name,double price,int number,double specialPrice,double totalPrice){
		this.ID=ID;
		this.name=name;
		this.price=price;
		this.number=number;
		this.specialPrice=specialPrice;
		this.totalPrice=totalPrice;
	}
	public int getID(){
		return ID;
	}
	public void setID(int ID){
		this.ID=ID;
	}
	public String getName(){
		return name;
	}
	public void setName(String name){
		this.name=name;
	}
	public double getPrice(){
		return price;
	}
	public void setPrice(int price){
		this.price=price;
	}
	public int getNum(){
		return number;
	}
	public void setNum(int number){
		this.number=number;
	}
	public double getSpecialPrice(){
		return specialPrice;
	}
	public void setSpecialPrice(int specialPrice){
		this.specialPrice=specialPrice;
	}
	public double getTotalPrice(){
		return totalPrice;
	}
	public void setTotalPrice(int totalPrice){
		this.totalPrice=totalPrice;
	}
}
