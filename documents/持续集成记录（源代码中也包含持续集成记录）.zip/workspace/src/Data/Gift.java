package Data;
import java.io.Serializable;

public class Gift implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int ID;
	private String name;
	private int number;
	
	public Gift(int ID,String name,int number){
		this.set(ID, name, number);
	}
	public void set(int ID,String name,int number){
		this.ID=ID;
		this.name=name;
		this.number=number;
	}
	public int getID(){
		return ID;
	}
	public void setID(int ID){
		this.ID=ID;
	}
	public String getName(){
		return name;
	}
	public void setName(String name){
		this.name=name;
	}
	public int getNum(){
		return number;
	}
	public void setNum(int number){
		this.number=number;
	}
}
