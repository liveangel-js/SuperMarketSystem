package Data;
import java.io.Serializable;
public class ItemReturn implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
}
