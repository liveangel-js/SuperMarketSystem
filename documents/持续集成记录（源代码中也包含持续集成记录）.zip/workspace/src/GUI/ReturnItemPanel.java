package GUI;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.table.*;


public class ReturnItemPanel extends JPanel implements ActionListener{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextField text_bill;
	private JButton button_bill;
	private JTextField text_item_id;
	private JTextField text_item_num;
	private JButton button_item;
	private DefaultTableModel mode;
	private JTextField text_patback_price;
	private JButton button_price;
	CashierPanel cp;
	
	
	
	public ReturnItemPanel(CashierPanel cp){
		this.cp=cp;
        this.setLayout(new FlowLayout());
		
		
		//�վ����
		JPanel pvip=new JPanel();
		pvip.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "�վ�"));
		pvip.add(new JLabel("�վݱ��:"));
		text_bill=new JTextField(12);
		pvip.add(text_bill);
		button_bill=new JButton("ȷ��");
		button_bill.addActionListener(this);
		pvip.add(button_bill);
		this.add(pvip);
		
		
		
		//������Ʒ���
		JPanel pitem=new JPanel();
		pitem.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "��Ʒ����"));
		pitem.add(new JLabel("��ƷID:"));
		text_item_id=new JTextField(12);
		pitem.add(text_item_id);
		pitem.add(new JLabel("��Ʒ��Ŀ:"));
		text_item_num=new JTextField(12);
		pitem.add(text_item_num);
		button_item=new JButton("ȷ��");
		button_item.addActionListener(this);
		pitem.add(button_item);
		this.add(pitem);
		
		
		
		//������Ʒ�б����
		String[] columnNames ={"ID","����","����","�Żݼ�","����","�ܼ�"};
		mode = new DefaultTableModel(columnNames, 0);
		JTable itemTable = new JTable(mode);
		itemTable.setEnabled(false);
		JScrollPane pitemList=new JScrollPane(itemTable);
		pitemList.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "��Ʒ����"));
		this.add(pitemList);
		
		
		
		//�۸�֧�����
		JPanel pprice=new JPanel();
		pprice.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "���֧��"));
		pprice.add(new JLabel("�˿�:"));
		text_patback_price=new JTextField(12);
		pprice.add(text_patback_price);
		button_price=new JButton("ȷ��");
		button_price.addActionListener(this);
		pprice.add(button_price);
		this.add(pprice);
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==button_bill){
			
		}
		if(e.getSource()==button_item){
			
		}
		if(e.getSource()==button_price){
			
		}
	}

}
