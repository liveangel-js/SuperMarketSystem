package fakeData;

import Data.VIP;
public class TestLogicVipData extends VIP {
	
	public int getID(){
		return 2;
	}
	
}
