package fakeData;
import Data.Item;
public class TestLogicItemData extends Item{
	public int getID(){
		return 2;
	}
}
