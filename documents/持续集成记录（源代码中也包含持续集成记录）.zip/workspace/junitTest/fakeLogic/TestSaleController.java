package fakeLogic;
import Logic.Controller;


public class TestSaleController extends Controller {
		public static String getValidPoint(){
			return "500";
		}
		
		
		public static String[] getItemListInfo(){
			String[] itemListInfo=new String[2];
			itemListInfo[0]=2+","+"item2"+","+ 11.5+","+10+","+9.5+","+95;
			itemListInfo[1]=1+","+"帽子"+","+ 12.5+","+10.5+","+10+","+105;
			return itemListInfo;
		}
		public static String getPrice(){
			
			return "200";
		}
		public static int getItemNum(){
			return 0;
		}

	}


